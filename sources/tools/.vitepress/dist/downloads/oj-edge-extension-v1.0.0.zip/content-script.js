// content-script.js - 接收页面消息并转发到后台
window.addEventListener('message', function(event) {
  if (event.source !== window) return;
  if (event.data && event.data.type === 'OJ_PROBLEM_DATA') {
    chrome.runtime.sendMessage({
      type: 'PROBLEM_DATA',
      url: event.data.url,
      data: event.data.data
    });
  }
});