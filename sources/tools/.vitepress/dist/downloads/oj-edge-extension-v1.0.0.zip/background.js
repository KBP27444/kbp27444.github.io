// background.js - 后台服务，缓存题目数据，点击图标时发送到VSCode
let ws = null;

// 连接到本地WebSocket服务器（VSCode扩展提供的）
function connectToVSCode() {
  if (ws && ws.readyState === WebSocket.OPEN) return;

  ws = new WebSocket('ws://127.0.0.1:8765');

  ws.onopen = () => {
    console.log('已连接到VSCode');
  };

  ws.onclose = () => {
    console.log('VSCode连接断开，5秒后重连...');
    setTimeout(connectToVSCode, 5000);
  };

  ws.onerror = (err) => {
    console.error('WebSocket错误:', err);
  };
}

// 启动时连接
connectToVSCode();

// 收到内容脚本发来的数据 → 只缓存，不立即处理
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'PROBLEM_DATA') {
    chrome.storage.session.set({ lastProblem: message.data }).then(() => {
      console.log('已缓存最新题目数据（等待点击扩展图标触发）');
    });
    sendResponse({ status: 'ok' });
  }
  return true;
});

// 点击扩展图标 → 从缓存取出并处理
chrome.action.onClicked.addListener(async () => {
  const { lastProblem } = await chrome.storage.session.get('lastProblem');

  if (!lastProblem) {
    console.warn('没有缓存的题目数据，请先刷新题目页');
    chrome.action.setBadgeBackgroundColor({ color: '#d9534f' });
    chrome.action.setBadgeText({ text: '×' });
    setTimeout(() => chrome.action.setBadgeText({ text: '' }), 1500);
    return;
  }

  console.log('检测到图标点击，开始处理缓存的题目数据');
  const ok = handleProblemData(lastProblem);

  if (ok) {
    chrome.action.setBadgeBackgroundColor({ color: '#5cb85c' });
    chrome.action.setBadgeText({ text: '✓' });
  } else {
    chrome.action.setBadgeBackgroundColor({ color: '#d9534f' });
    chrome.action.setBadgeText({ text: '!' });
  }
  setTimeout(() => chrome.action.setBadgeText({ text: '' }), 1500);
});

// 解析数据并发送到 VSCode
function handleProblemData(rawData) {
  try {
    let json = JSON.parse(rawData);

    // 解一层 data 包裹
    if (json.data && typeof json.data === 'object') {
      json = json.data;
    }

    const title = json.title;
    const statement = json.statement;

    if (!title) {
      console.warn('未找到title字段，实际字段有:', Object.keys(json));
      return false;
    }
    if (!statement) {
      console.warn('未找到statement字段，实际字段有:', Object.keys(json));
      return false;
    }

    console.log('提取成功:', { title, statementLength: statement.length });
    sendToVSCode(title, statement);
    return true;
  } catch (e) {
    console.error('解析数据失败:', e);
    return false;
  }
}

function sendToVSCode(title, content) {
  if (!ws || ws.readyState !== WebSocket.OPEN) {
    console.warn('VSCode未连接，尝试重连...');
    connectToVSCode();
    setTimeout(() => {
      if (ws && ws.readyState === WebSocket.OPEN) {
        sendToVSCode(title, content);
      }
    }, 1000);
    return;
  }

  ws.send(JSON.stringify({
    type: 'CREATE_FILE',
    filename: title + '.md',
    content: content
  }));

  console.log('已发送到VSCode:', title + '.md');
}