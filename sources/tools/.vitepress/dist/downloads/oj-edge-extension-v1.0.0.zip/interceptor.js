// interceptor.js - 注入到页面主世界，拦截fetch和XHR
(function() {
  // 不区分大小写地判断 URL 是否为题目信息接口
  const isProblemAPI = (u) => typeof u === 'string' && /problem/i.test(u);

  const originalFetch = window.fetch;

  window.fetch = async function(...args) {
    const response = await originalFetch.apply(this, args);
    const url = response.url || (args[0]?.url || args[0]);

    if (isProblemAPI(url)) {
      const clone = response.clone();
      try {
        const text = await clone.text();
        window.postMessage({
          type: 'OJ_PROBLEM_DATA',
          url: url,
          data: text
        }, '*');
      } catch (e) {
        console.error('OJ Extractor: 解析响应失败', e);
      }
    }
    return response;
  };

  // 拦截 XMLHttpRequest
  const originalXHROpen = XMLHttpRequest.prototype.open;
  const originalXHRSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    this._oj_url = url;
    return originalXHROpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = function(...args) {
    this.addEventListener('load', function() {
      if (isProblemAPI(this._oj_url)) {
        try {
          const text = this.responseText;
          window.postMessage({
            type: 'OJ_PROBLEM_DATA',
            url: this._oj_url,
            data: text
          }, '*');
        } catch (e) {
          console.error('OJ Extractor: XHR解析失败', e);
        }
      }
    });
    return originalXHRSend.apply(this, args);
  };
})();